const express = require('express');
const router = express.Router();
const albumController = require('../controllers/albumController');


// Ruta para obtener todos los álbumes
router.get('/a', albumController.getAllAlbums);

// Ruta para obtener un álbum por ID
router.get('/:id', albumController.getAlbumsById);


// Ruta para crear un nuevo álbum
router.post('/', albumController.createAlbums);

// Otras rutas para actualizar, eliminar, etc.

module.exports = router;