const express = require('express');
const router = express.Router();
const songController = require('../controllers/songController');

// Obtener todas las canciones
router.get('/a', songController.getAllSongs);

// Obtener una canción por ID
router.get('/:id', songController.getSongById);

// Crear una nueva canción
router.post('/', songController.createSong);

// Actualizar una canción
router.put('/:id', songController.updateSong);

// Eliminar una canción
router.delete('/:id', songController.deleteSong);

module.exports = router;