const mongoose = require('mongoose');

const albumSchema = new mongoose.Schema({
  title: String,
  year: Number,
  description: String,
  songs: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Song' }]
});

module.exports = mongoose.model('album', albumSchema);