
const Album = require('../models/album'); // Importamos el modelo de Álbum 

const getAllAlbums = async (req, res) => {
  try {
    const albums = await Album.find();
    res.json(albums);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error al obtener los álbumes' });
  }
};


const createAlbums = async (req, res) => {
  try {
      const album = new Album(req.body);
      await album.save();
      res.status(201).json(album);
  } catch (error) {
      console.error(error);
      res.status(400).json({ message: 'Error al crear el álbum' });
  }
};

const getAlbumsById = async (req, res) => {
  try {
      const album = await Album.findById(req.params.id);
      if (!album) {
          return res.status(404).json({ message: 'Álbum no encontrado' });
      }
      res.json(album);
  } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Error al obtener el álbum' });
  }
};


module.exports = {
  createAlbums,
  getAllAlbums,
  getAlbumsById,
};