const Song = require('../models/song'); // Importa el modelo de canción

// Crear una nueva canción
const createSong = async (req, res) => {
    try {
        // Crea una nueva instancia del modelo Song a partir de los datos de la solicitud
        const newSong = new Song(req.body);

        // Guarda la nueva canción en la base de datos
        const savedSong = await newSong.save();

        // Envía una respuesta exitosa con la canción creada
        res.status(201).json(savedSong);
    } catch (error) {
        console.error(error);
        res.status(400).json({ message: 'Error al crear la canción' });
    }
};

// Obtener todas las canciones
const getAllSongs = async (req, res) => {
    try {
        const songs = await Song.find();
        res.json(songs);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error al obtener las canciones' });
    }
};

// Obtener una canción por ID
const getSongById = async (req, res) => {
    try {
        const song = await Song.findById(req.params.id);
        if (!song) {
            return res.status(404).json({ message: 'Canción no encontrada' });
        }
        res.json(song);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error al obtener la canción' });
    }
};

// Actualizar una canción
const updateSong = async (req, res) => {
    // ... Implementación similar a getSongById, pero luego actualiza los campos
};

// Eliminar una canción
const deleteSong = async (req, res) => {
    // ... Implementación para eliminar una canción por ID
};

module.exports = {
    createSong,
    getAllSongs,
    getSongById,
    updateSong,
    deleteSong
};