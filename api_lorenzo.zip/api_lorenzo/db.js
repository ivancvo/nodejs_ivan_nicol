const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost/mi-coleccion-musical', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('Conectado a MongoDB'))
  .catch(err => console.error(err));